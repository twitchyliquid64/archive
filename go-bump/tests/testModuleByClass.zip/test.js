TESTING_HARNESS_BYCLASS = JSON.stringify(api.moduleByClass("testClassName"));
