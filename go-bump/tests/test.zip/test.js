console.log("API VERSION: "+ api.version);
app.sayHello("Tom");
api.sleep(1000);
console.log(JSON.stringify(api.modulesLoaded()));
