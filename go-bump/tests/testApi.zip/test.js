TESTING_HARNESS = GOBUMP_VERSION_STRING+api.version;
TESTING_HARNESS_MODULES = JSON.stringify(api.modulesLoaded());
TESTING_HARNESS_MODLIST = JSON.stringify(api.moduleExports("tests/testApi.zip"));
