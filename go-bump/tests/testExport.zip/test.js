
var testExport = function(strInput, intInput){
	return strInput + " " + (intInput*3);
};
