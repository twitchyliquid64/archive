function double(ina){
	return ina*2;
};

TESTING_HARNESS_RETVAL = api.moduleCall("tests/testSelfCall.zip", "double", "444");
